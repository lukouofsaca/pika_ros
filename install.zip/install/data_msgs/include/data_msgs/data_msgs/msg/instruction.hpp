// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__INSTRUCTION_HPP_
#define DATA_MSGS__MSG__INSTRUCTION_HPP_

#include "data_msgs/msg/detail/instruction__struct.hpp"
#include "data_msgs/msg/detail/instruction__builder.hpp"
#include "data_msgs/msg/detail/instruction__traits.hpp"
#include "data_msgs/msg/detail/instruction__type_support.hpp"

#endif  // DATA_MSGS__MSG__INSTRUCTION_HPP_

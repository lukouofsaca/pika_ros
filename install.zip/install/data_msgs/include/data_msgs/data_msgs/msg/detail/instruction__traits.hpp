// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from data_msgs:msg/Instruction.idl
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__DETAIL__INSTRUCTION__TRAITS_HPP_
#define DATA_MSGS__MSG__DETAIL__INSTRUCTION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "data_msgs/msg/detail/instruction__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'start_stamp'
// Member 'end_stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace data_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Instruction & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: text
  {
    out << "text: ";
    rosidl_generator_traits::value_to_yaml(msg.text, out);
    out << ", ";
  }

  // member: start_stamp
  {
    out << "start_stamp: ";
    to_flow_style_yaml(msg.start_stamp, out);
    out << ", ";
  }

  // member: end_stamp
  {
    out << "end_stamp: ";
    to_flow_style_yaml(msg.end_stamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Instruction & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: text
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "text: ";
    rosidl_generator_traits::value_to_yaml(msg.text, out);
    out << "\n";
  }

  // member: start_stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "start_stamp:\n";
    to_block_style_yaml(msg.start_stamp, out, indentation + 2);
  }

  // member: end_stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "end_stamp:\n";
    to_block_style_yaml(msg.end_stamp, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Instruction & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace data_msgs

namespace rosidl_generator_traits
{

[[deprecated("use data_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const data_msgs::msg::Instruction & msg,
  std::ostream & out, size_t indentation = 0)
{
  data_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use data_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const data_msgs::msg::Instruction & msg)
{
  return data_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<data_msgs::msg::Instruction>()
{
  return "data_msgs::msg::Instruction";
}

template<>
inline const char * name<data_msgs::msg::Instruction>()
{
  return "data_msgs/msg/Instruction";
}

template<>
struct has_fixed_size<data_msgs::msg::Instruction>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<data_msgs::msg::Instruction>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<data_msgs::msg::Instruction>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DATA_MSGS__MSG__DETAIL__INSTRUCTION__TRAITS_HPP_

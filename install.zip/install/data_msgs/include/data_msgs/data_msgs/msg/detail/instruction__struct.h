﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from data_msgs:msg/Instruction.idl
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__DETAIL__INSTRUCTION__STRUCT_H_
#define DATA_MSGS__MSG__DETAIL__INSTRUCTION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'text'
#include "rosidl_runtime_c/string.h"
// Member 'start_stamp'
// Member 'end_stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/Instruction in the package data_msgs.
/**
  * 消息头
 */
typedef struct data_msgs__msg__Instruction
{
  std_msgs__msg__Header header;
  /// 识别的文本
  rosidl_runtime_c__String text;
  /// 语音开始时间戳
  builtin_interfaces__msg__Time start_stamp;
  /// 语音结束时间戳
  builtin_interfaces__msg__Time end_stamp;
} data_msgs__msg__Instruction;

// Struct for a sequence of data_msgs__msg__Instruction.
typedef struct data_msgs__msg__Instruction__Sequence
{
  data_msgs__msg__Instruction * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} data_msgs__msg__Instruction__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DATA_MSGS__MSG__DETAIL__INSTRUCTION__STRUCT_H_

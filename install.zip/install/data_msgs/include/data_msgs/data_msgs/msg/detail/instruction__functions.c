// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from data_msgs:msg/Instruction.idl
// generated code does not contain a copyright notice
#include "data_msgs/msg/detail/instruction__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `text`
#include "rosidl_runtime_c/string_functions.h"
// Member `start_stamp`
// Member `end_stamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
data_msgs__msg__Instruction__init(data_msgs__msg__Instruction * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    data_msgs__msg__Instruction__fini(msg);
    return false;
  }
  // text
  if (!rosidl_runtime_c__String__init(&msg->text)) {
    data_msgs__msg__Instruction__fini(msg);
    return false;
  }
  // start_stamp
  if (!builtin_interfaces__msg__Time__init(&msg->start_stamp)) {
    data_msgs__msg__Instruction__fini(msg);
    return false;
  }
  // end_stamp
  if (!builtin_interfaces__msg__Time__init(&msg->end_stamp)) {
    data_msgs__msg__Instruction__fini(msg);
    return false;
  }
  return true;
}

void
data_msgs__msg__Instruction__fini(data_msgs__msg__Instruction * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // text
  rosidl_runtime_c__String__fini(&msg->text);
  // start_stamp
  builtin_interfaces__msg__Time__fini(&msg->start_stamp);
  // end_stamp
  builtin_interfaces__msg__Time__fini(&msg->end_stamp);
}

bool
data_msgs__msg__Instruction__are_equal(const data_msgs__msg__Instruction * lhs, const data_msgs__msg__Instruction * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // text
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->text), &(rhs->text)))
  {
    return false;
  }
  // start_stamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->start_stamp), &(rhs->start_stamp)))
  {
    return false;
  }
  // end_stamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->end_stamp), &(rhs->end_stamp)))
  {
    return false;
  }
  return true;
}

bool
data_msgs__msg__Instruction__copy(
  const data_msgs__msg__Instruction * input,
  data_msgs__msg__Instruction * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // text
  if (!rosidl_runtime_c__String__copy(
      &(input->text), &(output->text)))
  {
    return false;
  }
  // start_stamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->start_stamp), &(output->start_stamp)))
  {
    return false;
  }
  // end_stamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->end_stamp), &(output->end_stamp)))
  {
    return false;
  }
  return true;
}

data_msgs__msg__Instruction *
data_msgs__msg__Instruction__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_msgs__msg__Instruction * msg = (data_msgs__msg__Instruction *)allocator.allocate(sizeof(data_msgs__msg__Instruction), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(data_msgs__msg__Instruction));
  bool success = data_msgs__msg__Instruction__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
data_msgs__msg__Instruction__destroy(data_msgs__msg__Instruction * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    data_msgs__msg__Instruction__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
data_msgs__msg__Instruction__Sequence__init(data_msgs__msg__Instruction__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_msgs__msg__Instruction * data = NULL;

  if (size) {
    data = (data_msgs__msg__Instruction *)allocator.zero_allocate(size, sizeof(data_msgs__msg__Instruction), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = data_msgs__msg__Instruction__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        data_msgs__msg__Instruction__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
data_msgs__msg__Instruction__Sequence__fini(data_msgs__msg__Instruction__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      data_msgs__msg__Instruction__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

data_msgs__msg__Instruction__Sequence *
data_msgs__msg__Instruction__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  data_msgs__msg__Instruction__Sequence * array = (data_msgs__msg__Instruction__Sequence *)allocator.allocate(sizeof(data_msgs__msg__Instruction__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = data_msgs__msg__Instruction__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
data_msgs__msg__Instruction__Sequence__destroy(data_msgs__msg__Instruction__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    data_msgs__msg__Instruction__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
data_msgs__msg__Instruction__Sequence__are_equal(const data_msgs__msg__Instruction__Sequence * lhs, const data_msgs__msg__Instruction__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!data_msgs__msg__Instruction__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
data_msgs__msg__Instruction__Sequence__copy(
  const data_msgs__msg__Instruction__Sequence * input,
  data_msgs__msg__Instruction__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(data_msgs__msg__Instruction);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    data_msgs__msg__Instruction * data =
      (data_msgs__msg__Instruction *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!data_msgs__msg__Instruction__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          data_msgs__msg__Instruction__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!data_msgs__msg__Instruction__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}

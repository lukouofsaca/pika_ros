#!/bin/bash

echo "export pika_L_code=$1" >> ~/.bashrc

echo "export pika_R_code=$2" >> ~/.bashrc

source ~/.bashrc
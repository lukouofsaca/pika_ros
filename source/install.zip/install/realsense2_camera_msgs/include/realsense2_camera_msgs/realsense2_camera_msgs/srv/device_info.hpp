// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__SRV__DEVICE_INFO_HPP_
#define REALSENSE2_CAMERA_MSGS__SRV__DEVICE_INFO_HPP_

#include "realsense2_camera_msgs/srv/detail/device_info__struct.hpp"
#include "realsense2_camera_msgs/srv/detail/device_info__builder.hpp"
#include "realsense2_camera_msgs/srv/detail/device_info__traits.hpp"
#include "realsense2_camera_msgs/srv/detail/device_info__type_support.hpp"

#endif  // REALSENSE2_CAMERA_MSGS__SRV__DEVICE_INFO_HPP_

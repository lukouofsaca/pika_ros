// generated from rosidl_generator_c/resource/idl.h.em
// with input from piper_msgs:msg/PiperStatusMsg.idl
// generated code does not contain a copyright notice

#ifndef PIPER_MSGS__MSG__PIPER_STATUS_MSG_H_
#define PIPER_MSGS__MSG__PIPER_STATUS_MSG_H_

#include "piper_msgs/msg/detail/piper_status_msg__struct.h"
#include "piper_msgs/msg/detail/piper_status_msg__functions.h"
#include "piper_msgs/msg/detail/piper_status_msg__type_support.h"

#endif  // PIPER_MSGS__MSG__PIPER_STATUS_MSG_H_

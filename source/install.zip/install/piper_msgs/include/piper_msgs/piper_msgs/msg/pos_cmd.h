// generated from rosidl_generator_c/resource/idl.h.em
// with input from piper_msgs:msg/PosCmd.idl
// generated code does not contain a copyright notice

#ifndef PIPER_MSGS__MSG__POS_CMD_H_
#define PIPER_MSGS__MSG__POS_CMD_H_

#include "piper_msgs/msg/detail/pos_cmd__struct.h"
#include "piper_msgs/msg/detail/pos_cmd__functions.h"
#include "piper_msgs/msg/detail/pos_cmd__type_support.h"

#endif  // PIPER_MSGS__MSG__POS_CMD_H_

// generated from rosidl_generator_c/resource/idl.h.em
// with input from data_msgs:msg/Instruction.idl
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__INSTRUCTION_H_
#define DATA_MSGS__MSG__INSTRUCTION_H_

#include "data_msgs/msg/detail/instruction__struct.h"
#include "data_msgs/msg/detail/instruction__functions.h"
#include "data_msgs/msg/detail/instruction__type_support.h"

#endif  // DATA_MSGS__MSG__INSTRUCTION_H_

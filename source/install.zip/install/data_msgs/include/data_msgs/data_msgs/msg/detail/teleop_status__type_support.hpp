// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from data_msgs:msg/TeleopStatus.idl
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__DETAIL__TELEOP_STATUS__TYPE_SUPPORT_HPP_
#define DATA_MSGS__MSG__DETAIL__TELEOP_STATUS__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "data_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_data_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  data_msgs,
  msg,
  TeleopStatus
)();
#ifdef __cplusplus
}
#endif

#endif  // DATA_MSGS__MSG__DETAIL__TELEOP_STATUS__TYPE_SUPPORT_HPP_

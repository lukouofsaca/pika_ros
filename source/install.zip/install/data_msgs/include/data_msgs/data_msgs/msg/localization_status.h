// generated from rosidl_generator_c/resource/idl.h.em
// with input from data_msgs:msg/LocalizationStatus.idl
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__LOCALIZATION_STATUS_H_
#define DATA_MSGS__MSG__LOCALIZATION_STATUS_H_

#include "data_msgs/msg/detail/localization_status__struct.h"
#include "data_msgs/msg/detail/localization_status__functions.h"
#include "data_msgs/msg/detail/localization_status__type_support.h"

#endif  // DATA_MSGS__MSG__LOCALIZATION_STATUS_H_
